package app.ofbusiness.com.geofencing.utils;

public class MapConstant {

    public static final float DEFAULT_CAMERA_ZOOM = 18f;

    public static final int CIRCLE_RADIUS = 100;

}
